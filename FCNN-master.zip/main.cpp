/////////////////////////////////////////////////////////////////////////////
// Authored by Jeong-Mo Hong for CSE4060 course at Dongguk University CSE  //
// jeongmo.hong@gmail.com                                                  //
// Do whatever you want license.                                           //
/////////////////////////////////////////////////////////////////////////////

#include <iostream>

#include "NeuralNetwork.h"

using namespace std;

void main()
{
	VectorND<D> x(2);
	//x[0] = 0.0; x[1] = 0.0;

	VectorND<D> y_target(2);
	//y_target[0] = 0.0f;

	VectorND<D> y_temp(2);

	NeuralNetwork nn_;
	nn_.initialize(2, 1, 1);
	nn_.alpha_ = 0.00001;

	// (0, 0) -> 0
	x[0] = 0.0; x[1] = 0.0;
	y_target[0] = 0.0f;

	for (int i = 0; i < 100; i++)
	{
		
		nn_.setInputVector(x);
		nn_.propForward();

		nn_.copyOutputVector(y_temp);
		std::cout << y_temp << std::endl;

		nn_.propBackward(y_target);
	}

	// (0, 1) -> 1
	x[0] = 0.0; x[1] = 1.0;
	y_target[0] = 1.0f;

	for (int i = 0; i < 100; i++)
	{

		nn_.setInputVector(x);
		nn_.propForward();

		nn_.copyOutputVector(y_temp);
		std::cout << y_temp << std::endl;

		nn_.propBackward(y_target);
	}

	// (1, 0) -> 1
	x[0] = 1.0; x[1] = 0.0;
	y_target[0] = 1.0f;

	for (int i = 0; i < 100; i++)
	{

		nn_.setInputVector(x);
		nn_.propForward();

		nn_.copyOutputVector(y_temp);
		std::cout << y_temp << std::endl;

		nn_.propBackward(y_target);
	}

	// (1, 1) -> 0
	x[0] = 1.0; x[1] = 1.0;
	y_target[0] = 0.0f;

	for (int i = 0; i < 100; i++)
	{

		nn_.setInputVector(x);
		nn_.propForward();

		nn_.copyOutputVector(y_temp);
		std::cout << y_temp << std::endl;

		nn_.propBackward(y_target);
	}
	cout << "******* finish learning *******" << endl;
	// (0.5, 0.5) -> ?
	x[0] = 0.5; x[1] = 0.5;

	nn_.setInputVector(x);
	nn_.propForward();

	nn_.copyOutputVector(y_temp);
	std::cout << "(0.5, 0.5) result: " << y_temp << std::endl;

	// (0.7, 0.8) -> ?
	x[0] = 0.7; x[1] = 0.8;

	nn_.setInputVector(x);
	nn_.propForward();

	nn_.copyOutputVector(y_temp);
	std::cout << "(0.7, 0.8) result: " << y_temp << std::endl;
}