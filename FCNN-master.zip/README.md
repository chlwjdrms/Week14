# FCNN
This is a class-room level implementation of the fully connected neural network example.

Implemented on Windows 10 with Visual Studio 2015 Community.

Link to FCNN lecture: http://blog.naver.com/atelierjpro/220773276384

Link to all lectures: http://blog.naver.com/atelierjpro/220697890605

